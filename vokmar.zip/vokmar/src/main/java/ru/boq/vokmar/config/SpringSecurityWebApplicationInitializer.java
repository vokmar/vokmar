package ru.boq.vokmar.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringSecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {
}
